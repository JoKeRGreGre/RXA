package selector;

public class Main {

	public static void main(String[] args) {
		
		int port = 1025;
		new Serveur(port);
	}
	
}
